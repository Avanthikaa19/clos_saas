import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FlowManagerDataService } from 'src/app/flow-manager/services/flow-manager-data.service';

@Component({
  selector: 'app-field-mapper-fragment',
  templateUrl: './field-mapper-fragment.component.html',
  styleUrls: ['./field-mapper-fragment.component.scss']
})
export class FieldMapperFragmentComponent implements OnInit {
  //ace editor options
  options: any = { maxLines: 5000, printMargin: false, useWorker: false };
  
  //script eval tester popup
  evaluate: boolean = false;
  content: string = '';
  text: string;

  //to store config.fieldMapping node as a model
  configValue: FieldMapperConfigFragmentModel;
  @Output() configChange = new EventEmitter<any>();

  @Input()
  get config() {
    return this.configValue;
  }
  set config(val) {
    this.configValue = val;
    this.configChange.emit(this.configValue);
  }

  //this component variables
  loadingFormulas: boolean = false;
  formulas: string[] = [];

  constructor(
    private flowManagerDataService: FlowManagerDataService
  ) { }

  ngOnInit(): void {
    this.refreshFormulasList();
  }

  refreshFormulasList() {
    this.loadingFormulas = true;
    this.flowManagerDataService.getConfigurationFormulas('FIELD_MAPPER').subscribe(
      res => {
        this.formulas = res;
        this.loadingFormulas = false;
      },
      err => {
        this.loadingFormulas = false;
      }
    );
  }

  testEvaluateOnClickTest() {
    console.log(this.text);
    this.flowManagerDataService.getEvaluate(this.text).subscribe(
      (res: any) => {
        console.log(res);
        this.content = res;
      },
      (err: any) => {
        console.log(err);
        this.content = err.error;
      }
    );
  }

}

export class FieldMapperConfigFragmentModel {
  fill: string;
  fieldsAre: string;
  definedBy: {
    giveAs: string,
    name: string,
    formula: string,
    value: string
  }[];
}
