import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { SplitterConfigurationComponent } from './splitter-configuration.component';

describe('SplitterConfigurationComponent', () => {
  let component: SplitterConfigurationComponent;
  let fixture: ComponentFixture<SplitterConfigurationComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ SplitterConfigurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SplitterConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
