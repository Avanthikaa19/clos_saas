import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { DataFilterConfigurationComponent } from './data-filter-configuration.component';

describe('DataFilterConfigurationComponent', () => {
  let component: DataFilterConfigurationComponent;
  let fixture: ComponentFixture<DataFilterConfigurationComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ DataFilterConfigurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataFilterConfigurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
