import { Component, OnInit, EventEmitter, Output, Input, SecurityContext } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { FlowManagerDataService } from 'src/app/flow-manager/services/flow-manager-data.service';

@Component({
  selector: 'app-mail-sender-configuration',
  templateUrl: './mail-sender-configuration.component.html',
  styleUrls: ['./mail-sender-configuration.component.scss']
})
export class MailSenderConfigurationComponent implements OnInit {
  options1: any = { minLines: 1, maxLines: 5000, printMargin: false, useWorker: false };
  options2: any = { minLines: 10, maxLines: 5000, printMargin: false, useWorker: false };
  //two way binding to parent component
  configValue: MailSender;
  @Output() configChange = new EventEmitter<any>();
  @Input()
  get config() {
    return this.configValue;
  }
  set config(val) {
    this.configValue = val;
    this.configChange.emit(this.configValue);
  }

  preview: boolean = true;

  constructor(
    private flowManagerDataService: FlowManagerDataService,
    private sanitizer: DomSanitizer
  ) { }

  ngOnInit() {
    if (this.config == undefined || this.config == null) {
      this.flowManagerDataService.getDefaultConfiguration('MAIL_SENDER').subscribe(
        res => {
          // console.log(res.connection.acknowledgeMode)
          this.config = res;
          this.config.message.content = this.sanitizer.sanitize(SecurityContext.HTML, this.config.message.content)
          console.log(this.config);
        },
        err => {
          console.error(err.error);
        }
      );
    }
  }
  trackByIndex(index: number): number {
    return index;
  }

  debug() {
    console.log(this.config);
  }

}
export class MailSender {
  passThrough: boolean;
  task: {
    insertBatchSize: number,
    inputPollingMs: number,
    maxThreads: number
  };
  includeSystemProperties: boolean;
  properties: {
    name: string,
    type: string,
    enabled: boolean,
    value: string
  }[];
  addresses: {
    to: string[],
    cc: string[],
    bcc: string[]
  };
  message: {
    subject: string,
    content: string,
    attachments: string[]
  };
}