import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { StaticDataProcessorComponent } from './static-data-processor.component';

describe('StaticDataProcessorComponent', () => {
  let component: StaticDataProcessorComponent;
  let fixture: ComponentFixture<StaticDataProcessorComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ StaticDataProcessorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StaticDataProcessorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
